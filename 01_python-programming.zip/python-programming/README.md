# 🐍 Python Programming
**Paschal Uchendu | Gisma University of Applied Sciences**

This repository contains all my Python programming coursework, exercises, and mini-projects completed as part of my Computer Science degree. It covers core Python concepts from fundamentals through to object-oriented programming and file handling.

---

## 📁 Repository Structure

```
python-programming/
│
├── basics/               # Variables, data types, loops, conditionals
├── oop/                  # Classes, objects, inheritance, encapsulation
├── file-handling/        # Reading & writing files, CSV, JSON
├── mini-projects/        # Small standalone Python applications
└── README.md
```

---

## 📚 Topics Covered

| Topic | Folder | Status |
|-------|--------|--------|
| Variables & Data Types | `basics/` | ⬜ Add your files |
| Control Flow (if/else, loops) | `basics/` | ⬜ Add your files |
| Functions & Modules | `basics/` | ⬜ Add your files |
| Object-Oriented Programming | `oop/` | ⬜ Add your files |
| Inheritance & Polymorphism | `oop/` | ⬜ Add your files |
| File I/O (txt, CSV, JSON) | `file-handling/` | ⬜ Add your files |
| Mini Project 1 | `mini-projects/` | ⬜ Add your files |
| Mini Project 2 | `mini-projects/` | ⬜ Add your files |

---

## 🛠️ Tools & Technologies

- **Language:** Python 3.x
- **IDE:** VS Code / Jupyter Notebook
- **Version Control:** Git & GitHub

---

## 🚀 How to Run

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/python-programming.git
   ```
2. Navigate into the folder you want:
   ```bash
   cd python-programming/basics
   ```
3. Run any script:
   ```bash
   python filename.py
   ```

---

## 📝 Notes

> Add any personal notes about what you learned, challenges you faced, or things you want to revisit here.

---

## 👤 Author

**Paschal Uchendu**
📧 your.email@email.com
🔗 [GitHub](https://github.com/yourusername) | [LinkedIn](https://linkedin.com/in/yourusername)

---
*Part of my Computer Science Portfolio — Gisma University of Applied Sciences*
